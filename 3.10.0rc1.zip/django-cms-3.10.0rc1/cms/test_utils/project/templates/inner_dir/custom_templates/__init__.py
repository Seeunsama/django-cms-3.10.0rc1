from django.utils.translation import gettext_lazy as _

TEMPLATES = {
    'right_col_two.html': _('Two columns'),
    'right_col_three.html': _('Three columns'),
}
